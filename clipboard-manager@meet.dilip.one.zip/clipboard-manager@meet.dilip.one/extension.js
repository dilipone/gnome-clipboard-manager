import St from 'gi://St';
import Meta from 'gi://Meta';
import GObject from 'gi://GObject';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';

const MAX_HISTORY = 15;

const ClipboardIndicator = GObject.registerClass(
class ClipboardIndicator extends PanelMenu.Button {
    _init() {
        super._init(0.0, 'Clipboard Manager');
        
        this.history = [];
        this.clipboard = St.Clipboard.get_default();
        
        // Add top bar icon
        let icon = new St.Icon({
            icon_name: 'edit-copy-symbolic',
            style_class: 'system-status-icon',
        });
        this.add_child(icon);

        // History Section
        this.historySection = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this.historySection);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        // Clear Button
        let clearMenuItem = new PopupMenu.PopupMenuItem('🗑️ Clear Clipboard');
        clearMenuItem.connect('activate', () => this._clearClipboard());
        this.menu.addMenuItem(clearMenuItem);

        // Listen for clipboard changes (Wayland compatible)
        this._selection = global.display.get_selection();
        this._selectionId = this._selection.connect('owner-changed', (selection, selectionType, selectionSource) => {
            if (selectionType === Meta.SelectionType.SELECTION_CLIPBOARD) {
                this._getClipboardText();
            }
        });
        
        // Load initial state
        this._updateMenu();
    }

    _getClipboardText() {
        this.clipboard.get_text(St.ClipboardType.CLIPBOARD, (clipboard, text) => {
            if (text && text.trim() !== '') {
                this._addEntry(text);
            }
        });
    }

    _addEntry(text) {
        // Remove duplicate if it exists to push it to the top
        this.history = this.history.filter(item => item !== text);
        
        // Add to top of history
        this.history.unshift(text);
        
        // Enforce max limit
        if (this.history.length > MAX_HISTORY) {
            this.history.pop();
        }
        
        this._updateMenu();
    }

    _clearClipboard() {
        this.history = [];
        this.clipboard.set_text(St.ClipboardType.CLIPBOARD, "");
        this._updateMenu();
    }

    _updateMenu() {
        this.historySection.removeAll();
        
        if (this.history.length === 0) {
            let emptyItem = new PopupMenu.PopupMenuItem('Clipboard is empty', { reactive: false });
            this.historySection.addMenuItem(emptyItem);
            return;
        }

        this.history.forEach(text => {
            // Truncate long strings for the menu display
            let displayText = text.replace(/\n/g, ' ').substring(0, 40);
            if (text.length > 40) displayText += '...';
            
            let item = new PopupMenu.PopupMenuItem(displayText);
            item.connect('activate', () => {
                this.clipboard.set_text(St.ClipboardType.CLIPBOARD, text);
            });
            this.historySection.addMenuItem(item);
        });
    }

    destroy() {
        if (this._selectionId) {
            this._selection.disconnect(this._selectionId);
            this._selectionId = null;
        }
        super.destroy();
    }
});

export default class ClipboardManagerExtension extends Extension {
    enable() {
        this._indicator = new ClipboardIndicator();
        Main.panel.addToStatusArea(this.uuid, this._indicator);
    }

    disable() {
        if (this._indicator) {
            this._indicator.destroy();
            this._indicator = null;
        }
    }
}
